import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        var produtoList = List.of(
                new Produto("Arroz", "30.00"),
                new Produto("Feijão", "20.00"),
                new Produto("Bolacha", "3.00"));

        var exportador = ExportadorListaProduto.newInstance();
        System.out.println(exportador.exportart(produtoList));
    }
}