public class ExportadorListaProdutoMarkdown extends AbstractExportadorListaProduto{
    public String abrirTabela(){return  "";}
    public String fecharTabela(){return "";}
    public String abrirLinha(){return "";}
    public String fecharLinha(){return "";}
    public String abrirLinhaTitulos(){return "-";}
    public String fecharLinhaTitulos(){return  "-";}
    public String abrirColuna() {return "|";}
    public String fecharColuna(){return "|";}
}
