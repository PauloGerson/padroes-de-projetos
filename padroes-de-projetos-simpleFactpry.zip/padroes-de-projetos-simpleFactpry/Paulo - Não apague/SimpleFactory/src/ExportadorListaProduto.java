import java.util.List;

public interface ExportadorListaProduto {

    public String abrirTabela();
    public String fecharTabela();
    public String abrirLinha();
    public String fecharLinha();
    public String abrirLinhaTitulos();
    public String fecharLinhaTitulos();
    public String abrirColuna() ;
    public String fecharColuna();

    public String exportart(List<Produto> listaProdutos);


    public static ExportadorListaProduto newInstance(){
        return new ExportadorListaProdutoHtml();
    }


    public  static  ExportadorListaProduto newInstance(String extencao){
        if(extencao.endsWith(".html")){
            return new ExportadorListaProdutoHtml();
        }

        if(extencao.endsWith(".md")){
            return  new ExportadorListaProdutoMarkdown();
        }

        throw new UnsupportedOperationException("Formato não suported..");
    }


    
}
