public class ExportadorListaProdutoHtml extends AbstractExportadorListaProduto{

    public String abrirTabela(){return  "<table>\n";}
    public String fecharTabela(){return "</table>";}
    public String abrirLinha(){return "<tr>";}
    public String fecharLinha(){return "</tr>\n";}
    public String abrirLinhaTitulos(){return "<th>";}
    public String fecharLinhaTitulos(){return  "</th>";}
    public String abrirColuna() {return "<td>";}
    public String fecharColuna(){return "</td>";}

}
