import java.util.List;

public abstract class AbstractExportadorListaProduto implements ExportadorListaProduto{
    protected static List<String> TITULOS_COLUNAS = List.of("nome", "valor");

    @Override
    public String exportart(List<Produto> listaProdutos) {

        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append(abrirTabela());
        stringBuilder.append(abrirLinha());
        for(String titulo : TITULOS_COLUNAS){
            stringBuilder.append(abrirLinhaTitulos());
            stringBuilder.append(titulo);
            stringBuilder.append(fecharLinhaTitulos());
        }
        stringBuilder.append(fecharLinha());
        for(Produto p: listaProdutos){

            stringBuilder.append(abrirLinha());

            stringBuilder.append(abrirColuna());
            stringBuilder.append(p.getNome());
            stringBuilder.append(fecharColuna());
            stringBuilder.append(abrirColuna());
            stringBuilder.append(p.getValor());
            stringBuilder.append(fecharColuna());

            stringBuilder.append(fecharLinha());
        }

    stringBuilder.append(fecharTabela());




        return  stringBuilder.toString();
    }
}
