package com.manoelcampos.retornoboleto;

import java.net.URI;
import java.util.function.Function;

public final class EstrategiaBoletoFactory {
    private EstrategiaBoletoFactory(){

    }

    public static Function<String[], Boleto> newStrategy(URI nomeArquivo) {
        if (nomeArquivo.toString().contains("banco-brasil"))
            return LeituraRetorno::processarLinhaBancoBrasil;
        if(nomeArquivo.toString().contains("bradesco"))
            return LeituraRetorno::processarLinhaBancoBradesco;


        throw new UnsupportedOperationException("Banco não suportado");
    }

}
