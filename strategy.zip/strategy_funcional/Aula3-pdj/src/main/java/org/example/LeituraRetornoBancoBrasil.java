package org.example;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.List;

public class LeituraRetornoBancoBrasil {

    public static List<Boleto> lerArquivo(String nomeArquivo) {
        var listaBoletos = new LinkedList<Boleto>();

        try {

            var linhas = Files.readAllLines(Paths.get(nomeArquivo));
            for (String linha : linhas) {
              var vetor = linha.split(";");
              var boleto = new Boleto();

              boleto.setId(Integer.parseInt(vetor[0]));
              boleto.setConBanco(vetor[1]);
              var formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy");
              boleto.setDataVencimento(LocalDate.parse(vetor[2], formatoData));
              var dataPag = LocalDate.parse(vetor[3], formatoData).atTime(0,0);
              boleto.setDataPagamento(dataPag);
              boleto.setCpfCLinete(vetor[4]);
              boleto.setValor(Double.parseDouble(vetor[5]));
              boleto.setMultas(Double.parseDouble(vetor[6]));
              boleto.setJuros(Double.parseDouble(vetor[7]));


              listaBoletos.add(boleto);

            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }



        return listaBoletos;
    }
}
