package org.example;

public class Main {
    public static void main(String[] args) {
        var processador = new ProcessarBoleto(LeituraRetornoBancoBrasil ::lerArquivo);
        processador.processar("banco-brasil-1.csv");

    }
}