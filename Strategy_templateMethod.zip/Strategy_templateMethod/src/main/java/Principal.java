import com.manoelcampos.retornoboleto.LeituraRetornoBancoBrasil;
import com.manoelcampos.retornoboleto.ProcessarBoletos;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * Classe para ver o funcionamento da leitura de boletos.
 *
 * @author Manoel Campos da Silva Filho
 */
public class Principal {
    public static void main(String[] args) throws URISyntaxException {
        /*Instancia o objeto estrategista ProcessarBoletos,
        * indicando qual estratégia de leitura de boletos ele vai usar agora.
        * Neste caso, estamos iniciando com a leitura de boletos do Banco do Brasil.*/
        final ProcessarBoletos processador = new ProcessarBoletos(new LeituraRetornoBancoBrasil());

        URI caminhoArquivo = Principal.class.getResource("banco-brasil-1.csv").toURI();
        System.out.println("Lendo arquivo " + caminhoArquivo + "\n");

        processador.processar(caminhoArquivo);

    }
}
