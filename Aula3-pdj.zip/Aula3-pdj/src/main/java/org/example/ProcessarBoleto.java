package org.example;

public class ProcessarBoleto {
    private LeituraRetorno leituraRetorno;

    public ProcessarBoleto(LeituraRetorno leituraRetorno) {
        this.leituraRetorno = leituraRetorno;
    }

    public void processar(String nomeArquivo){

       var listaboletos =  leituraRetorno.lerArquivo(nomeArquivo);
       for (Boleto boleto: listaboletos){
           System.out.println(boleto);
       }
    }

    public void setLeituraRetorno(LeituraRetorno leituraRetorno) {
        this.leituraRetorno = leituraRetorno;
        }
}
