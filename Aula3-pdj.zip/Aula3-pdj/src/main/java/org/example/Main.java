package org.example;

public class Main {
    public static void main(String[] args) {
        var processador = new ProcessarBoleto(new LeituraRetornoBancoBrasil());
        processador.processar("banco-brasil-1.csv");
    }
}