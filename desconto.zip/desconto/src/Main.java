import java.time.LocalDate;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
       //String dataNacimento = Parse  LocalDate.of (2023, 01, 01);
        System.out.println (LocalDate.now());
    }
}