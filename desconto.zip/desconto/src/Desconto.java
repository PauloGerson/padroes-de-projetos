public interface Desconto {

    double calcular(Venda venda);

}
