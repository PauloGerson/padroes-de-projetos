import java.time.LocalDate;

public class DescontoAniversario implements Desconto {
    @Override
    public double calcular(Venda venda) {
        //Venda descontoA = new Venda ();

        if(venda.getDataNascimento().equals(LocalDate.now ())){
            System.out.println ("");
        }

        return 0;
    }
}
