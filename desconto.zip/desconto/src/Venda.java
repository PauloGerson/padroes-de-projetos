

import java.time.LocalDate;

public class Venda extends Cliente{

    private long id;
    private Cliente cliente;
    private LocalDate data;
    private double valorTotal;

    public Venda() {/**/}

    public Venda(Cliente cliente, LocalDate data, double valorTotal) {
        this.cliente = cliente;
        this.data = data;
        this.valorTotal = valorTotal;
    }

}
