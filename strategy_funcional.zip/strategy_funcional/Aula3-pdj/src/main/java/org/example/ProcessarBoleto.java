package org.example;

import java.util.List;
import java.util.function.Function;

public class ProcessarBoleto {
    private Function<String, List<Boleto>> leituraRetorno;

    public ProcessarBoleto(Function<String, List<Boleto>> leituraRetorno) {
        this.leituraRetorno = leituraRetorno;
    }

    public void processar(String nomeArquivo){

       List<Boleto>  listaboletos =  leituraRetorno.apply(nomeArquivo);
       for (Boleto boleto: listaboletos){
           System.out.println(boleto);
       }
    }

    public void setLeituraRetorno(Function<String, List<Boleto>>  leituraRetorno) {
        this.leituraRetorno = leituraRetorno;
        }
}
