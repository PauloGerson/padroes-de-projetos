import java.util.List;

public interface ExportadorListaProduto {
    public String abrirTabela();
    public String fecharTabela();
    public String abrirLinha();
    public String fecharLinha();
    public String abrirLinhaTitulos();
    public String fecharLinhaTitulos();
    public String abrirColuna(String valor);
    public String fecharColuna(String valor);

    public String exportart(List<Produto> listaProdutos);

    
}
